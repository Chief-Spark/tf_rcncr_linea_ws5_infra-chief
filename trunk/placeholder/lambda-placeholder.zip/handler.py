"""Placeholder de IaC (tf_rcncr_linea_ws5_infra).

La Lambda se crea por Terraform con este paquete. El codigo real lo publica el
pipeline del repo de codigo con `aws lambda update-function-code`. Mientras
tanto, cualquier invocacion falla (en el Authorizer: el API niega el acceso).
"""


def lambda_handler(event, context):
    raise RuntimeError("Codigo pendiente de despliegue: esta Lambda tiene el paquete placeholder de IaC")
